# რეპორტი სიმულაციის.

```
Pray ran into infinity
Pray ran into infinity
Some R-rated things have happened
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Some R-rated things have happened
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Some R-rated things have happened
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
Pray ran into infinity
```

ანუ 3-ჯერ შეჭამა predator-მა prey.

ესე დავრანავთ.

```
poetry run python -m pvspgame.runner.cli --count 100
```

ასევე დავამატე ვიზაულიზაციის და უკეთესი უფრო დიდი ლოგების ფუნქციონალიც.
ვიზუალიზაციის და დეტალური ლოგების ჩასართავად:

```
poetry run python -m pvspgame.runner.cli --count 10 --seed 42 --visualize --verbose
```
